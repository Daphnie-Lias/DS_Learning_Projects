import unittest
from url_shorten.views import short
from unittest import mock
import datetime
from http import HTTPStatus

class TestUrlShorten(unittest.TestCase):

    def test_shorten(self):
        post_data = { "url": "https://www.energyworx.com/", "shortcode": "ewx123" }
        body = short.shorten(post_data)
        response = self.fetch(r'/shorten', method='POST', body=body)
        self.assertEqual(response.code, 201)
        self.assertEqual(response.body, b'{"shortcode": "ewx123')

    def test_valid_url(self):
        url = 'http://www.google.com'

        self.assertTrue(short.uri_validate(url))

    def test_missing_url(self):

        response = self.client.get('https://some-id/missing-url/')
        assert response.status_code == HTTPStatus.NOT_FOUND, 'Url not present'
        assert response.json['code']
        assert response.json['message']

    def test_empty_url_not_valid(self):
        url = ''

        self.assertFalse(short.uri_validate(url))

    def test_generate_shortcode(self):

        code = short.generate_short_link()
        assert any(substr.isdigit() or substr.isalpha() for substr in code)

    def test_date_format(self):

        #return datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
        assert(self.test_date_format())


if __name__ =='__main__':
    unittest.main()