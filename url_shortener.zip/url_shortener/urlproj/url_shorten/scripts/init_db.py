"""This script is used to initialize the Database tables."""

from url_shorten.models import db

db.create_all()